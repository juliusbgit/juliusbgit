DIB Elements
============

Elements used by diskimage-builder for building images with nodepool-builder.
